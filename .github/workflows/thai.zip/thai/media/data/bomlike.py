import json
import os, time
import sys, urllib, argparse
from CHRLINE import *
import axolotl_curve25519 as Curve25519
from justgood import imjustgood

TOKEN = "token bomlike"
token = sys.argv[1]
to = sys.argv[2]
mid = sys.argv[3]
postid = sys.argv[4]
if __name__ == "__main__":
    assert TOKEN != ""
    cl = CHRLINE(token, device="ANDROID", version="12.10.0")
    cl.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    tok = TOKEN.split("|")
    cb = CHRLINE(tok[0], device="ANDROID", version="12.10.0")
    cb.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl1 = CHRLINE(tok[1], device="ANDROID", version="12.10.0")
    cl1.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl2 = CHRLINE(tok[2], device="ANDROID", version="12.10.0")
    cl2.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl3 = CHRLINE(tok[3], device="ANDROID", version="12.10.0")
    cl3.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl4 = CHRLINE(tok[4], device="ANDROID", version="12.10.0")
    cl4.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl5 = CHRLINE(tok[5], device="ANDROID", version="12.10.0")
    cl5.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl6 = CHRLINE(tok[6], device="ANDROID", version="12.10.0")
    cl6.createLike(mid,postid,likeType="1001",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl7 = CHRLINE(tok[7], device="ANDROID", version="12.10.0")
    cl7.createLike(mid,postid,likeType="1002",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl8 = CHRLINE(tok[8], device="ANDROID", version="12.10.0")
    cl8.createLike(mid,postid,likeType="1004",sharable=False,sourceType="TIMELINE")
    time.sleep(2)
    cl.sendMessage(to,"Done bom 10 like")
    print(f"success")
    exit()