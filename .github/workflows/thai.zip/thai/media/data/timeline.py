import json
import os
import sys, urllib, argparse
from CHRLINE import *
import axolotl_curve25519 as Curve25519
from justgood import imjustgood

TOKEN = sys.argv[1]
to = sys.argv[2]
mid = sys.argv[3]
postid = sys.argv[4]
type = sys.argv[5]

def urlEncode(url, path, params=[]):
    return url + path + '?' + urllib.parse.urlencode(params)

def getStoryMedia(mid=None):
    if mid == None:
        mid = profile.mid
    data = cl.getStory(mid)
    result = []
    if data['message'] == 'success':
        if data['result']['contents']:
           for media in data['result']['contents']:
                if media['media'][0]['mediaType'] == 'IMAGE':
                    params = {'userid': mid, 'oid': media['media'][0]['oid']}
                    url = urlEncode("https://obs-sg.line-apps.com",'/story/st/download.nhn', params)
                    result.append({
                        "type": "image",
                        "url": url
                    })
                if media['media'][0]['mediaType'] == 'VIDEO':
                    params = {'userid': mid, 'oid': media['media'][0]['oid']}
                    url = urlEncode("https://obs-sg.line-apps.com",'/story/st/download.nhn', params)
                    result.append({
                        "type": "video",
                        "url": url
                    })
    return result

if __name__ == "__main__":
    assert TOKEN != ""
    cl = CHRLINE(TOKEN, device="ANDROID", version="12.10.0")
    if type == "getstory":
        data = getStoryMedia(mid)
        if data:
            cl.sendMessage(to, "Downloading stories..")
            dataImages = []
            dataVideos = []
            for media in data:
                if media["type"] == "image":
                    dataImages.append(media["url"])
                elif media["type"] == "video":
                    cl.sendVideo(to, media["url"])
            if dataImages:
                if len(dataImages) >= 2:
                    cl.sendImage(to, dataImages)
                else:
                    cl.sendImage(to, dataImages[0])
        else:
            cl.sendMessage(to, "This user didnt upload any story")
            print(f"success")
            exit()
    if type == "likepost":    
        cl.createLike(mid,postid,likeType="1003",sharable=False,sourceType="TIMELINE")
        cl.createComment(mid,postid,"like post by golangbot x-CoDer™",stickerId=None,stickerPackageId=None,mediaObjectId=None,mediaObjectType="PHOTO", mediaObjectFrom="cmt",sourceType="TIMELINE")
        cl.sendMessage(to,"Done like post")
        print(f"success")
        exit()
    if type == "extracover":        
        try:
            a = cl.getProfileDetail(mid)
            b = "https://obs.line-scdn.net/r/stymedia/pf/"
            for data in a["result"]["userStyleMedia"]["components"]:
                if data["type"] == "PFRAME":
                    for res in data["data"]:
                        cl.sendImage(to, b+res["media"]["objectId"]) 
        except:
            cl.sendMessage(to, "This user didnt upload any extracover")
            print(f"success")
            exit()
    if type == "cover":       
        try:
            if mid is None:
                mid = cl.profile.mid
            profileDetail = cl.getProfileDetail(mid)
            if 'videoCoverObsInfo' in profileDetail['result']:
                params = {'userid': mid, 'oid': profileDetail['result']['videoCoverObsInfo']['objectId']}
                url = urlEncode("https://obs-sg.line-apps.com", '/myhome/vc/download.nhn', params)
                cl.sendVideo(to, url)
            else:
                params = {'userid': mid, 'oid': profileDetail['result']['coverObsInfo']['objectId']}
                url = urlEncode("https://obs-sg.line-apps.com", '/myhome/c/download.nhn', params)
                cl.sendImage(to, url)
        except:
            cl.sendMessage(to, "This user didnt upload any cover")
            print(f"success")
            exit()