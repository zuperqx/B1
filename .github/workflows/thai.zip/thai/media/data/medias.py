import json
import os
import sys
import random
from CHRLINE import *
import axolotl_curve25519 as Curve25519
from justgood import imjustgood

TOKEN = sys.argv[1]
to = sys.argv[2]
type = sys.argv[3]
search = sys.argv[4]
apikey = sys.argv[5]


if __name__ == "__main__":
    assert TOKEN != ""
    cl = CHRLINE(TOKEN, device="ANDROID", version="12.10.0")
    if type == "cuaca":
        api   =  imjustgood(apikey)
        data  =  api.cuaca(search)
        result   =  "{}".format(data["result"]["location"])
        result  +=  "\n    Cuaca : {}".format(data["result"]["description"])
        result  +=  "\n    Suhu : {}".format(data["result"]["temperature"])
        result  +=  "\n    Angin : {}".format(data["result"]["wind"])
        result  +=  "\n    Kelembapan : {}".format(data["result"]["humidity"])
        cl.sendMessage(to, result)
        print(f"success")
        exit()
    if type == "artinama":
        api   =  imjustgood(apikey)
        data  =  api.nama(search)
        result   =  "Nama : {}".format(data["result"]["name"])
        result  +=  "\n    Karakter : {}".format(data["result"]["definition"])
        result  +=  "\n    Deskripsi : {}".format(data["result"]["description"])
        cl.sendMessage(to, result)
        print(f"success")
        exit()
    if type == "simi":
        api   =  imjustgood(apikey)
        data  =  api.simisimi(search)
        result = data["result"]
        cl.sendMessage(to, result)
        print(f"success")
        exit()
    if type == "calculator":
        api   =  imjustgood(apikey)
        data  =  api.calc(search)
        result = data["result"]
        cl.sendMessage(to, result)
        print(f"success")
        exit()
    if type == "image_text":
        api   =  imjustgood(apikey)
        data  =  api.imagetext(search)
        result = data["result"]
        cl.sendImage(to, result)
        print(f"success")
        exit()
    if type == "google":
        api   =  imjustgood(apikey)
        data    =  api.image(search)
        for i in range(len(data["result"])):
            result = data["result"][i]
            cl.sendImage(to, result)
            print(f"success")
            exit()
    if type == "hentai":
        api   =  imjustgood(apikey)
        data    =  api.hentai()
        for i in range(len(data["result"])):
            result = data["result"][i]
            cl.sendImage(to, result)
            print(f"success")
            exit()
    if type == "youtube":
        api   =  imjustgood(apikey)
        data     =  api.youtube(search)
        result = "Youtube Search:"
        result  +=  "\n    Title: {}".format(data["result"]["title"])
        result  +=  "\n    Author: {}".format(data["result"]["author"])
        result  +=  "\n    Duration: {}".format(data["result"]["duration"])
        result  +=  "\n    Watched: {}".format(data["result"]["watched"])
        result  +=  "\n    Description: {}".format(data["result"]["watched"])
        cl.sendMessage(to, result)
        mp4 = data["result"]["videoUrl"]
        cl.sendVideo(to, mp4)
        mp3 = data["result"]["audioUrl"]
        cl.sendAudio(to, mp3)
        print(f"success")
        exit()
    if type == "tiktok":
        api   =  imjustgood(apikey)
        data     =  api.tiktok(search)
        result   =  "Tiktok Search:"
        result  +=  "\n    Username: {}".format(data["result"]["username"])
        result  +=  "\n    Fullname: {}".format(data["result"]["fullname"])
        result  +=  "\n    Private: {}".format(data["result"]["private"])
        result  +=  "\n    Verified: {}".format(data["result"]["private"])
        result  +=  "\n    Biography: {}".format(data["result"]["biography"])
        result  +=  "\n    Followers: {}".format(data["result"]["followers"])
        result  +=  "\n    Following: {}".format(data["result"]["following"])
        result  +=  "\n    Likes: {}".format(data["result"]["likes"])
        result  +=  "\n    Videos: {}".format(data["result"]["videos"])
        result  +=  "\n    Website: {}".format(data["result"]["website"])
        result  +=  "\n    Youtube: {}".format(data["result"]["social"]["youtube"])
        result  +=  "\n    Twitter: {}".format(data["result"]["social"]["twitter"])
        result  +=  "\n    Instagram: {}".format(data["result"]["social"]["instagram"])
        image = data["result"]["pictureUrl"]
        cl.sendImage(to, image)
        cl.sendMessage(to, result)
        print(f"success")
        exit()
    if type == "instagram":
        api   =  imjustgood(apikey)
        data     =  api.instagram(search)
        result   =  "Instagram Search:"
        result  +=  "\n    ID: {}".format(data["result"]["id"])
        result  +=  "\n    Username: {}".format(data["result"]["username"])
        result  +=  "\n    Fullname: {}".format(data["result"]["fullname"])
        result  +=  "\n    Biography: {}".format(data["result"]["biography"])
        result  +=  "\n    Website: {}".format(data["result"]["website"])
        result  +=  "\n    Private: {}".format(data["result"]["private"])
        result  +=  "\n    Verified: {}".format(data["result"]["verified"])
        result  +=  "\n    Business: {}".format(data["result"]["business"]["status"])
        result  +=  "\n    Category: {}".format(data["result"]["business"]["category"])
        result  +=  "\n    Follower: {}".format(data["result"]["follower"])
        result  +=  "\n    Following: {}".format(data["result"]["following"])
        result  +=  "\n    Post: {}".format(data["result"]["post"])
        image = data["result"]["picture"]
        cl.sendImage(to, image)
        cl.sendMessage(to, result)
        print(f"success")
        exit()
    if type == "joox":
        api   =  imjustgood(apikey)
        data     =  api.joox(search)
        result = "Joox Search:"
        result  +=  "\n    Singer: {}".format(data["result"]["singer"])
        result  +=  "\n    Title: {}".format(data["result"]["title"])
        result  +=  "\n    Album: {}".format(data["result"]["album"])
        result  +=  "\n    Duration: {}".format(data["result"]["duration"])
        result  +=  "\n    Filesize: {}".format(data["result"]["size"])
        cl.sendMessage(to, result)
        mp3 = data["result"]["mp3Url"]
        cl.sendAudio(to, mp3)
        print(f"success")
        exit()
    if type == "smule":
        api   =  imjustgood(apikey)
        data     =  api.smule(search)
        result   =  "Smule Search:" 
        result  +=  "\n    Account Id: {}".format(data["result"]["accountId"])
        result  +=  "\n    Username : {}".format(data["result"]["username"])
        result  +=  "\n    Fullname : {}".format(data["result"]["fullname"])
        result  +=  "\n    Biography : {}".format(data["result"]["biography"])
        result  +=  "\n    Location : {}".format(data["result"]["location"])
        result  +=  "\n    Followers : {}".format(data["result"]["followers"])
        result  +=  "\n    Following : {}".format(data["result"]["following"])
        result  +=  "\n    Recording : {}".format(data["result"]["recording"])
        result  +=  "\n    VIP : {}".format(data["result"]["vip"])
        result  +=  "\n    Verified : {}".format(data["result"]["verified"])
        image = data["result"]["pictureUrl"]
        cl.sendImage(to, image)
        cl.sendMessage(to, result)
        print(f"success")
        exit()
    if type == "pinterest":
        api   =  imjustgood(apikey)
        data    =  api.pinsearch(search)
        for i in range(len(data["result"])):
            result = data["result"][i]
            cl.sendImage(to, result)
            print(f"success")
            exit()
    if type == "pornstart":
        api   =  imjustgood(apikey)
        data     =  api.pornstar()
        main     =  random.choice(data["result"])
        result = main["image"]
        cl.sendImage(to, result)
        print(f"success")
        exit()
    if type == "pornvideo":
        api   =  imjustgood(apikey)
        data = api.porn(search)
        mp4 = data["result"]["videoUrl"]
        cl.sendVideo(to, mp4)
        print(f"success")
        exit()