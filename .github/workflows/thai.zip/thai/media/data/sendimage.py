import json
import os
import sys
from CHRLINE import *
import axolotl_curve25519 as Curve25519
from justgood import imjustgood

TOKEN = sys.argv[1]
to = sys.argv[2]
link = sys.argv[3]

if __name__ == "__main__":
    assert TOKEN != ""
    cl = CHRLINE(TOKEN, device="ANDROID", version="12.10.0")
    cl.sendImage(to, link)
    print(f"success")
    exit()