import json
import os
import sys
from CHRLINE import *
import axolotl_curve25519 as Curve25519
from justgood import imjustgood

TOKEN = sys.argv[1]
to = sys.argv[2]
type = sys.argv[3]
url = sys.argv[4]
apikey = sys.argv[5]

if __name__ == "__main__":
    assert TOKEN != ""
    cl = CHRLINE(TOKEN, device="ANDROID", version="12.10.0")
    if type == "snackvideo":
        api   =  imjustgood(apikey)
        data     =  api.snackvideo(url)
        result   =  "Snackvideo Detail:"
        result   +=  "\n    ID: {}".format(data["result"]["profileId"])
        result  +=  "\n    Username: {}".format(data["result"]["username"])
        result  +=  "\n    Fullname: {}".format(data["result"]["fullname"])
        result  +=  "\n    Like: {}".format(data["result"]["like"])
        result  +=  "\n    Share: {}".format(data["result"]["share"])
        result  +=  "\n    Comment: {}".format(data["result"]["comment"])
        result  +=  "\n    Caption: {}".format(data["result"]["caption"])
        result  +=  "\n    Created: {}".format(data["result"]["created"])
        mp4 = data["result"]["video"]
        cl.sendMessage(to, result)
        cl.sendVideo(to, mp4)
        print(f"success")
        exit()
    if type == "smule":
        api   =  imjustgood(apikey)
        data     =  api.smuledl(url)
        result   =  "Smule Detail:"
        result   +=  "\n    Artist: {}".format(data["result"]["artist"])
        result  +=  "\n    Title: {}".format(data["result"]["title"])
        result  +=  "\n    Caption: {}".format(data["result"]["caption"])
        result  +=  "\n    Created: {}".format(data["result"]["created"])
        result  +=  "\n    Love: {}".format(data["result"]["loves"])
        result  +=  "\n    Gift: {}".format(data["result"]["gifts"])
        result  +=  "\n    Listen: {}".format(data["result"]["listens"])
        result  +=  "\n    Comment: {}".format(data["result"]["comments"])
        result  +=  "\n    Type: {}".format(data["result"]["type"])
        cl.sendMessage(to, result)
        if data["result"]["type"] == "video":
            mp4 = data["result"]["mp4Url"]
            cl.sendVideo(to, mp4)
        mp3 = data["result"]["mp3Url"]
        cl.sendAudio(to, mp3)
        print(f"success")
        exit()
    if type == "instagram":
        api   =  imjustgood(apikey)
        data = api.instapost(url)
        result = "Instagram Detail:"
        result  +=  "\n    Username: {}".format(data["result"]["username"])
        result  +=  "\n    Fullname: {}".format(data["result"]["fullname"])
        result  +=  "\n    Verified: {}".format(data["result"]["verified"])
        result  +=  "\n    Private: {}".format(data["result"]["private"])
        result  +=  "\n    Caption: {}".format(data["result"]["caption"])
        result  +=  "\n    Likes: {}".format(data["result"]["likes"])
        result  +=  "\n    Comments: {}".format(data["result"]["comments"])
        result  +=  "\n    Created: {}".format(data["result"]["created"])
        cl.sendMessage(to, result)
        for i in range(len(data["result"]["postData"])):
            main  =  data["result"]["postData"][i]
            if main["type"] == "image":
                image = main["postUrl"]
                cl.sendImage(to, image)
            if main["type"] == "video":
                video = main["postUrl"]
                cl.sendVideo(to, video)
            print(f"success")
            exit()
    if type == "facebook":
        api   =  imjustgood(apikey)
        data     =  api.facebookdl(url)
        result = "Facebook Detail:"
        result  +=  "\n    Author: {}".format(data["result"]["author"])
        result  +=  "\n    ID: {}".format(data["result"]["profileId"])
        result  +=  "\n    Desc: {}".format(data["result"]["caption"])
        result  +=  "\n    Likes: {}".format(data["result"]["likes"])
        result  +=  "\n    Loves: {}".format(data["result"]["loves"])
        result  +=  "\n    Share: {}".format(data["result"]["share"])
        result  +=  "\n    Views: {}".format(data["result"]["views"])
        result  +=  "\n    Comments: {}".format(data["result"]["comments"])
        mp4 = data["result"]["videoUrl"]
        cl.sendMessage(to, result)
        cl.sendVideo(to, mp4)
        print(f"success")
        exit()
    if type == "tiktok":
        api   =  imjustgood(apikey)
        data = api.tiktokdl(url)
        result   =  "Tiktok Detail:"
        result  +=  "\n    Username: {}".format(data["result"]["username"])
        result  +=  "\n    Fullname: {}".format(data["result"]["fullname"])
        result  +=  "\n    Caption: {}".format(data["result"]["caption"])
        result  +=  "\n    Like: {}".format(data["result"]["like"])
        result  +=  "\n    Share: {}".format(data["result"]["share"])
        result  +=  "\n    Comment: {}".format(data["result"]["comment"])
        result  +=  "\n    Duration: {}".format(data["result"]["duration"])
        result  +=  "\n    Playing: {}".format(data["result"]["play"])
        result  +=  "\n    Download: {}".format(data["result"]["download"])
        result  +=  "\n    Created: {}".format(data["result"]["created"])
        result  +=  "\n    Music: {}".format(data["result"]["music"])
        mp4 = data["result"]["no_watermark"]
        cl.sendMessage(to, result)
        cl.sendVideo(to, mp4)
        print(f"success")
        exit()